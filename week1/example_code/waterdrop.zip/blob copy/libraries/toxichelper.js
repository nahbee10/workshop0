// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Making it easier to use all these classes
// Maybe this is a bad idea?
var VerletPhysics2D = toxi.physics2d.VerletPhysics2D;
var GravityBehavior = toxi.physics2d.behaviors.GravityBehavior;
var AttractionBehavior = toxi.physics2d.behaviors.AttractionBehavior;
var VerletParticle2D = toxi.physics2d.VerletParticle2D;
var VerletSpring2D = toxi.physics2d.VerletSpring2D;
var VerletMinDistanceSpring2D = toxi.physics2d.VerletMinDistanceSpring2D;
var VerletConstrainedSpring2D = toxi.physics2d.VerletConstrainedSpring2D;
var Vec2D = toxi.geom.Vec2D;
var Rect =toxi.geom.Rect;
